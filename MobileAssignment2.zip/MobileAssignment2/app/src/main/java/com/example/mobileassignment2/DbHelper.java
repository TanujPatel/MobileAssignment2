package com.example.mobileassignment2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION=1;
    public static final String DATABASE_NAME = "Assignment2";
    public static final String TABLE_NAME = "coordinatesTable";
    public static final String COL_ID="id";
    public static final String COL_LATITUDE = "latitude";
    public static final String COL_LONGITUDE = "longitude";
    public static final String COL_ADDRESS = "address";
   // public static final String COL_POSITION = "position";



    public DbHelper (Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //create db
        String createTable = "CREATE TABLE "+TABLE_NAME+" ("+
                COL_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                COL_LATITUDE+" REAL, "+
                COL_LONGITUDE+" REAL, "+
                COL_ADDRESS+" TEXT)";
              //  COL_POSITION+" INTEGER)";

        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int old, int newVersion) {
        if(old>=newVersion)
            return;

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


    public void deleteEntry(String addy){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        //find entry by matching with addy
        String match=COL_ADDRESS +" =?";
        String[] selection ={addy};

        //delete the row
        sqLiteDatabase.delete(TABLE_NAME,match,selection);
    }

    public void updateDb(double lat, double longitude, String addy,String newAddy){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_LATITUDE, lat);
        values.put(COL_LONGITUDE, longitude);
        values.put(COL_ADDRESS,newAddy);

        //find the match in db with the addy
        String match=COL_ADDRESS +" =?";
        String[] selection ={addy};

        //update the db with new lat and longitude values
        sqLiteDatabase.update(TABLE_NAME,values,match,selection);
    }

    public void saveNew(double lat, double longitude, String addy){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_LATITUDE,lat);
        values.put(COL_LONGITUDE, longitude);
        values.put(COL_ADDRESS, addy);

        //insert the new lat longitude and addy into the db
        sqLiteDatabase.insert(TABLE_NAME,null,values);
    }

    public Cursor searchByAddress(String query){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();

        String [] findMatch ={COL_LATITUDE,COL_LONGITUDE,COL_ADDRESS};
        String match = COL_ADDRESS+" LIKE?";
        String[] selection = {"%"+query+"%"};

        String notDeleted = COL_ID + " IS NOT NULL";
        String[] notDeletedSelected ={};

        String combineSelection = match+" AND "+notDeleted;

        return sqLiteDatabase.query(TABLE_NAME,findMatch,combineSelection,selection,null,null,null);
    }
}
