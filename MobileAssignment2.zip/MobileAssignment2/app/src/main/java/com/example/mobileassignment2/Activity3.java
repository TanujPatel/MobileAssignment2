package com.example.mobileassignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class Activity3 extends AppCompatActivity {

    private DbHelper dbHelper;

    EditText edLatNew, edLongNew, edAddyNew;
    Button  doneButtonNew;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        edLatNew = (EditText) findViewById(R.id.editLatNew);
        edLongNew = (EditText) findViewById(R.id.editLongitudeNew);
        edAddyNew = (EditText) findViewById(R.id.editAddyNew);

        doneButtonNew = (Button) findViewById(R.id.doneBtnNew);

        doneButtonNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Geocoder geocoder = new Geocoder(Activity3.this, Locale.getDefault());
                String addy="";

                try{
                    List<Address> addresses = geocoder.getFromLocation(Double.parseDouble(edLatNew.getText().toString()),Double.parseDouble(edLongNew.getText().toString()), 1);

                    if(addresses!=null && addresses.size()>0){
                        Address returnedAddress = addresses.get(0);

                        addy=returnedAddress.getAddressLine(0);
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }
                edAddyNew.setText(addy);
                saveAddy();




            }
        });
    }

    private void saveAddy(){
        //get the new lat longitude and address
        double newLat = Double.parseDouble(edLatNew.getText().toString());
        double newLong = Double.parseDouble(edLongNew.getText().toString());
        String newAddress = edAddyNew.getText().toString();

        //save the new info into db
        DbHelper dbHelper1 = new DbHelper(this);
        dbHelper1.saveNew(newLat,newLong,newAddress);

        finish();
    }
}