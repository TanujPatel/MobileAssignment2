package com.example.mobileassignment2;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FileReader {
    public static List<String[]> readCoordinated(Context context, String fileName){
        List<String[]> coordinatesList = new ArrayList<>();

        try{
            //open file
            InputStream inputStream = context.getAssets().open(fileName);
            //buffer to read file
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            //read the file line by line until you reach the end
            while((line=reader.readLine())!=null){
                //split the line by ',' to get long and lat
                String[] coordinates = line.split(",");
                coordinatesList.add(coordinates);//add coordinates to the list
            }
            //close reader
            reader.close();
        }catch (IOException e){
            e.printStackTrace();
        }
        return coordinatesList;
    }

    public static String getAddy(Context context, double lat, double longitude){
        //intialize the geocoder
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        String addy="";//holds the new address

        try{
            List<Address> addresses = geocoder.getFromLocation(lat,longitude, 1);//get the location from the geocoder and store it in list

            if(addresses!=null && addresses.size()>0){
                //store the address in the addy variable
                Address returnedAddress = addresses.get(0);

                addy=returnedAddress.getAddressLine(0);
            }
        }catch (IOException e){
            e.printStackTrace();
        }
        return addy;
    }
}
