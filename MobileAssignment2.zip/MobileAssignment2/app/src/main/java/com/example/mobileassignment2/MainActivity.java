package com.example.mobileassignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private DbHelper dbHelper;
    private Button addButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DbHelper(this);
        addButton = (Button)findViewById(R.id.addBtn);


        List<String[]> coordinatesList;
        coordinatesList = FileReader.readCoordinated(this, "long_lat.txt");
        int counter =0;
        //go through the coordinates list to get the longitude and latitude
        for(String[] coordinates : coordinatesList){
            //convert the strings into a double
            double latitide = Double.parseDouble(coordinates[0]);
            double longitude = Double.parseDouble(coordinates[1]);
            //get address from longitude and latitude
            String addy = FileReader.getAddy(this, latitide,longitude);

            //save the long and lat and addy in db
            saveToDb(latitide, longitude, addy, counter);
            counter++;
        }

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });

        search();


    }


    public void search(){
        SearchView searchView = findViewById(R.id.searchAddy);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchDb(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

    }

    private void searchDb(String query){
        Cursor cursor = dbHelper.searchByAddress(query);

        if(cursor.getCount()!=0 && cursor.moveToFirst()){
            @SuppressLint("Range") double lat=cursor.getDouble(cursor.getColumnIndex(DbHelper.COL_LATITUDE));
            @SuppressLint("Range") double longitude=cursor.getDouble(cursor.getColumnIndex(DbHelper.COL_LONGITUDE));
            @SuppressLint("Range") String addy = cursor.getString(cursor.getColumnIndex(DbHelper.COL_ADDRESS));

            openActivity2(lat, longitude, addy);
            Toast.makeText(this, "Latitude: "+lat+ "\nLongitude: "+longitude+"\nAddress: "+addy,Toast.LENGTH_LONG).show();

        }
        else{
            Toast.makeText(this, "Nothing found", Toast.LENGTH_LONG).show();
        }

    }

    public void openActivity2(double lat, double longitude, String addy){
        Intent intent = new Intent(this,Activity2.class);
        //putExtra meethod is used to send the mortgage, tenure and interest values to the next activity
        //the method will take a string that acts as a key which will be used to recieve the values in the next activity it is being sent to
        intent.putExtra("message_key",lat);
        intent.putExtra("message_key2",longitude);
        intent.putExtra("message_key3",addy);
        startActivity(intent);//starts activity
    }

    public void openNewActivity(){
        Intent intent = new Intent(this,Activity3.class);
        startActivity(intent);
    }
    private void saveToDb(double lat, double longitude, String addy, int counter){
        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbHelper.COL_LATITUDE, lat);
        values.put(DbHelper.COL_LONGITUDE, longitude);
        values.put(DbHelper.COL_ADDRESS, addy);

        long newID = sqLiteDatabase.insert(DbHelper.TABLE_NAME, null, values);

        if(newID>-1){
            //Toast.makeText(this,"Data inserted successfully",Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(this,"Error inserted successfully",Toast.LENGTH_SHORT).show();

        }

    }





}