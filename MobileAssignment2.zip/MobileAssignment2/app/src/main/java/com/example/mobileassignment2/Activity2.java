package com.example.mobileassignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class Activity2 extends AppCompatActivity {
    private DbHelper dbHelper;

    EditText edLat, edLong, edAddy;
    Button deleteButton, doneButton;
    String addy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Intent intent = getIntent();//creating the object for get intent
        Double lat = intent.getDoubleExtra("message_key",0);
        Double longitude = intent.getDoubleExtra("message_key2",0);
         addy = intent.getStringExtra("message_key3");

        edLat = (EditText) findViewById(R.id.editLat);
        edLong = (EditText) findViewById(R.id.editLongitude);
        edAddy = (EditText) findViewById(R.id.editAddy);

        edLat.setText(lat.toString());
        edLong.setText(longitude.toString());
        edAddy.setText(addy);

        deleteButton = (Button) findViewById(R.id.deleteBtn);
        doneButton = (Button) findViewById(R.id.doneBtn);

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addy = edAddy.toString();
                if((addy.isEmpty())==false){
                    deleteAddy();

                }
            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((addy.isEmpty())==false){
                    updateAddy();
                }



            }
        });


    }

public void deleteAddy(){
    DbHelper dbHelper1 = new DbHelper(this);
    dbHelper1.deleteEntry(addy);

    finish();
}

public void updateAddy(){
        //get the input from the edit fields of the long and lat
        double updatedLat = Double.parseDouble(edLat.getText().toString());
        double updatedLong = Double.parseDouble(edLong.getText().toString());
        String addy = edAddy.getText().toString();
    // get the new address
    Geocoder geocoder = new Geocoder(this, Locale.getDefault());
    String updateaddy="";

    try{
        List<Address> addresses = geocoder.getFromLocation(updatedLat,updatedLong, 1);

        if(addresses!=null && addresses.size()>0){
            Address returnedAddress = addresses.get(0);

            updateaddy=returnedAddress.getAddressLine(0);
        }
    }catch (IOException e){
        e.printStackTrace();
    }
        //send the latitude and longitude to be updated in db
        DbHelper dbHelper1 = new DbHelper(this);
        dbHelper1.updateDb(updatedLat, updatedLong,addy, updateaddy);


        finish();
}


}